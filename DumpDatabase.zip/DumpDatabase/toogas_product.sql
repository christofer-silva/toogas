CREATE DATABASE  IF NOT EXISTS `toogas` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `toogas`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: toogas
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.11-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `sku` varchar(45) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` decimal(6,2) DEFAULT 0.00,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku_UNIQUE` (`sku`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `product_id_UNIQUE` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=183 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (133,1,'24-MB01','Joust Duffle Bag',34.00,1,'2020-07-30 10:11:41','2020-07-30 10:11:41'),(134,3,'24-MB03','Crown Summit Backpack',38.00,1,'2020-07-30 10:11:42','2020-07-30 10:11:42'),(135,4,'24-MB05','Wayfarer Messenger Bag',45.00,1,'2020-07-30 10:11:42','2020-07-30 10:11:42'),(136,5,'24-MB06','Rival Field Messenger',45.00,1,'2020-07-30 10:11:42','2020-07-30 10:11:42'),(137,6,'24-MB02','Fusion Backpack',59.00,1,'2020-07-30 10:11:42','2020-07-30 10:11:42'),(138,7,'24-UB02','Impulse Duffle',74.00,1,'2020-07-30 10:11:42','2020-07-30 10:11:42'),(139,8,'24-WB01','Voyage Yoga Bag',32.00,1,'2020-07-30 10:11:42','2020-07-30 10:11:42'),(140,9,'24-WB02','Compete Track Tote',32.00,1,'2020-07-30 10:11:42','2020-07-30 10:11:42'),(141,12,'24-WB03','Driven Backpack',36.00,1,'2020-07-30 10:11:43','2020-07-30 10:11:43'),(142,13,'24-WB07','Overnight Duffle',45.00,1,'2020-07-30 10:11:43','2020-07-30 10:11:43'),(143,14,'24-WB04','Push It Messenger Bag',45.00,1,'2020-07-30 10:11:43','2020-07-30 10:11:43'),(144,15,'24-UG06','Affirm Water Bottle ',7.00,1,'2020-07-30 10:11:43','2020-07-30 10:11:43'),(145,17,'24-UG04','Zing Jump Rope',12.00,1,'2020-07-30 10:11:43','2020-07-30 10:11:43'),(146,18,'24-UG02','Pursuit Lumaflex&trade; Tone Band',16.00,1,'2020-07-30 10:11:44','2020-07-30 10:11:44'),(147,19,'24-UG05','Go-Get\'r Pushup Grips',19.00,1,'2020-07-30 10:11:44','2020-07-30 10:11:44'),(148,20,'24-UG01','Quest Lumaflex&trade; Band',19.00,1,'2020-07-30 10:11:44','2020-07-30 10:11:44'),(149,21,'24-WG084','Sprite Foam Yoga Brick',5.00,1,'2020-07-30 10:11:44','2020-07-30 10:11:44'),(150,22,'24-WG088','Sprite Foam Roller',19.00,1,'2020-07-30 10:11:44','2020-07-30 10:11:44'),(151,23,'24-UG03','Harmony Lumaflex&trade; Strength Band Kit ',22.00,1,'2020-07-30 10:11:44','2020-07-30 10:11:44'),(152,24,'24-WG081-gray','Sprite Stasis Ball 55 cm',23.00,1,'2020-07-30 10:11:44','2020-07-30 10:11:44'),(153,25,'24-WG081-pink','Sprite Stasis Ball 55 cm',23.00,1,'2020-07-30 10:11:44','2020-07-30 10:11:44'),(154,26,'24-WG081-blue','Sprite Stasis Ball 55 cm',23.00,1,'2020-07-30 10:11:44','2020-07-30 10:11:44'),(155,27,'24-WG082-gray','Sprite Stasis Ball 65 cm',27.00,1,'2020-07-30 10:11:44','2020-07-30 10:11:44'),(156,28,'24-WG082-pink','Sprite Stasis Ball 65 cm',27.00,1,'2020-07-30 10:11:44','2020-07-30 10:11:44'),(157,29,'24-WG082-blue','Sprite Stasis Ball 65 cm',27.00,1,'2020-07-30 10:11:44','2020-07-30 10:11:44'),(158,30,'24-WG083-gray','Sprite Stasis Ball 75 cm',32.00,1,'2020-07-30 10:11:45','2020-07-30 10:11:45'),(159,31,'24-WG083-pink','Sprite Stasis Ball 75 cm',32.00,1,'2020-07-30 10:11:45','2020-07-30 10:11:45'),(160,32,'24-WG083-blue','Sprite Stasis Ball 75 cm',32.00,1,'2020-07-30 10:11:45','2020-07-30 10:11:45'),(161,33,'24-WG085','Sprite Yoga Strap 6 foot',14.00,1,'2020-07-30 10:11:45','2020-07-30 10:11:45'),(162,34,'24-WG086','Sprite Yoga Strap 8 foot',17.00,1,'2020-07-30 10:11:45','2020-07-30 10:11:45'),(163,35,'24-WG087','Sprite Yoga Strap 10 foot',21.00,1,'2020-07-30 10:11:45','2020-07-30 10:11:45'),(164,36,'24-MG04','Aim Analog Watch',45.00,1,'2020-07-30 10:11:45','2020-07-30 10:11:45'),(165,37,'24-MG01','Endurance Watch',49.00,1,'2020-07-30 10:11:46','2020-07-30 10:11:46'),(166,38,'24-MG03','Summit Watch',54.00,1,'2020-07-30 10:11:46','2020-07-30 10:11:46'),(167,39,'24-MG05','Cruise Dual Analog Watch',55.00,1,'2020-07-30 10:11:46','2020-07-30 10:11:46'),(168,40,'24-MG02','Dash Digital Watch',92.00,1,'2020-07-30 10:11:46','2020-07-30 10:11:46'),(169,43,'24-WG03','Clamber Watch',54.00,1,'2020-07-30 10:11:46','2020-07-30 10:11:46'),(170,44,'24-WG02','Didi Sport Watch',92.00,1,'2020-07-30 10:11:46','2020-07-30 10:11:46'),(171,45,'24-WG085_Group','Set of Sprite Yoga Straps',0.00,1,'2020-07-30 10:11:47','2020-07-30 10:11:47'),(172,46,'24-WG080','Sprite Yoga Companion Kit',0.00,1,'2020-07-30 10:11:48','2020-07-30 10:11:48'),(173,2,'24-MB04','Strive Shoulder Pack',32.00,1,'2020-07-30 10:11:42','2020-07-30 10:16:22'),(174,10,'24-WB05','Savvy Shoulder Tote',32.00,1,'2020-07-30 10:11:42','2020-07-30 10:16:25'),(175,11,'24-WB06','Endeavor Daytrip Backpack',33.00,1,'2020-07-30 10:11:43','2020-07-30 10:16:26'),(176,16,'24-UG07','Dual Handle Cardio Ball',12.00,1,'2020-07-30 10:11:43','2020-07-30 10:16:27'),(177,41,'24-WG09','Luma Analog Watch',43.00,1,'2020-07-30 10:11:46','2020-07-30 10:16:27'),(178,42,'24-WG01','Bolo Sport Watch',49.00,1,'2020-07-30 10:11:46','2020-07-30 10:16:27'),(179,47,'240-LV04','Beginner\'s Yoga',6.00,1,'2020-07-30 10:11:51','2020-07-30 10:11:51'),(180,48,'240-LV05','LifeLong Fitness IV',14.00,1,'2020-07-30 10:11:52','2020-07-30 10:11:52'),(181,49,'240-LV06','Yoga Adventure',22.00,1,'2020-07-30 10:11:52','2020-07-30 10:11:52'),(182,50,'240-LV07','Solo Power Circuit',14.00,1,'2020-07-30 10:11:52','2020-07-30 10:11:52');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-08 10:07:59
